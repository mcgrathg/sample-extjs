{
    "className": "sl.panel.grid.column.Cost",
    "classAlias": "widget.costcolumn",
    "autoName": "MyCost",
    "inherits": "Ext.grid.column.Number",
	"configs": [{
        "name": "formatAsSupplierCost",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "formatAsShopCost",
        "type": "boolean",
        "initialValue": false
    }, {
        "name": "formatAsRetail",
        "type": "boolean",
        "initialValue": false
    }, {
        "name": "showZeroIfEmpty",
        "type": "boolean",
        "initialValue": false
    }],
    "toolbox": {
        "name": "Cost (Stewarts-5)",
        "category": "Column",
        "groups": ["Column"]
    }
}