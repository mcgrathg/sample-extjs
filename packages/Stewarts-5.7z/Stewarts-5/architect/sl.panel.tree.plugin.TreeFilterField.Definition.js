{
    "className": "sl.panel.tree.plugin.TreeFilterField",
    "classAlias": "plugin.treefilterfield",
    "autoName": "MyTreeFilterField",
    "inherits": "sl.panel.grid.plugin.GridFilterField",
	"configs": [],
    "toolbox": {
        "name": "TreeFilterField (Stewarts-5)",
        "category": "Plugin",
        "groups": ["Plugin"]
    }
}