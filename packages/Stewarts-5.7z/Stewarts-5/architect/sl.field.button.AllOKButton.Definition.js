{
    "className": "sl.field.button.AllOKButton",
    "classAlias": "widget.allOKbutton",
    "autoName": "MyAllOKButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "AllOKButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}