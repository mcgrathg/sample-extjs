{
    "className": "sl.field.button.DeleteWithUndoButton",
    "classAlias": "widget.deletewithundobutton",
    "autoName": "MyDeleteWithUndoButton",
    "inherits": "Ext.button.Split",
	"configs": [],
    "toolbox": {
        "name": "DeleteWithUndoButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}