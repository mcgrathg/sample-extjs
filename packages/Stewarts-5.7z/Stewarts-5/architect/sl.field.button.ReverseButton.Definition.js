{
    "className": "sl.field.button.ReverseButton",
    "classAlias": "widget.reversebutton",
    "autoName": "MyReverseButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "ReverseButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}