{
    "className": "sl.panel.grid.plugin.GridFilterField",
    "classAlias": "plugin.gridfilterfield",
    "autoName": "MyGridFilterField",
    "inherits": "Ext.AbstractPlugin",
	"configs": [{
        "name": "selectAllText",
        "type": "string",
        "initialValue": "Select All"
    }, {
        "name": "toolbarId",
        "type": "string"
    }, {
        "name": "toolbarPosition",
        "type": "string",
        "initialValue": "bottom"
    }, {
        "name": "preCheckedIndexes",
        "type": "array"
    }, {
        "name": "excludedDataIndexes",
        "type": "array"
    }, {
        "name": "readonlyIndexes",
        "type": "array"
    }, {
        "name": "dateFormat",
        "type": "string"
    }, {
        "name": "showSelectAll",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "menuStyle",
        "type": "string",
        "initialValue": "checkbox"
    }, {
        "name": "minChars",
        "type": "number"
    }, {
        "name": "mode",
        "type": "string",
        "initialValue": "local"
    }, {
        "name": "fieldWidth",
        "type": "number",
        "initialValue": 200
    }, {
        "name": "paramNames",
        "type": "object",
        "initialValue": {fields: "fields", query: "query"}
    }, {
        "name": "shortcutKey",
        "type": "string"
    }, {
        "name": "searchOnClear",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "align",
        "type": "string",
        "initialValue": "right"
    }],
    "toolbox": {
        "name": "GridFilterField (Stewarts-5)",
        "category": "Plugin",
        "groups": ["Plugin"]
    }
}