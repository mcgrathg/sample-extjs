{
    "className": "sl.field.button.CopyButton",
    "classAlias": "widget.copybutton",
    "autoName": "MyCopyButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "CopyButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}