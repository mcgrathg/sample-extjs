{
    "className": "sl.data.file.FileStore",
    "classAlias": "store.file",
    "autoName": "MyFileStore",
    "inherits": "Ext.data.Store",
	"configs": [],
    "toolbox": {
        "name": "FileStore (Stewarts-5)",
        "category": "File",
        "groups": ["File"]
    }
}