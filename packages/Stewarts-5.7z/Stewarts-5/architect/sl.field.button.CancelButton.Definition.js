{
    "className": "sl.field.button.CancelButton",
    "classAlias": "widget.cancelbutton",
    "autoName": "MyCancelButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "CancelButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}