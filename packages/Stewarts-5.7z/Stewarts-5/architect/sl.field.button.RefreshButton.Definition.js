{
    "className": "sl.field.button.RefreshButton",
    "classAlias": "widget.refreshbutton",
    "autoName": "MyRefreshButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "RefreshButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}