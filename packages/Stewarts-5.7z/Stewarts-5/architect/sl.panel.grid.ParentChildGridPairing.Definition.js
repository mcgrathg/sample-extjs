{
    "className": "sl.panel.grid.ParentChildGridPairing",
    "classAlias": "plugin.parentchild",
    "autoName": "MyParentChildGridPairing",
    "inherits": "Ext.AbstractPlugin",
	"configs": [{
        "name": "parentGridReference",
        "type": "string"
    }, {
        "name": "childGridReference",
        "type": "string"
    }, {
        "name": "parentFieldName",
        "type": "string",
        "initialValue": "ID"
    }, {
        "name": "cacheParamName",
        "type": "string"
    }, {
        "name": "childForeignKeyFieldName",
        "type": "string"
    }, {
        "name": "childGridTitleSyncDisabled",
        "type": "boolean"
    }, {
        "name": "childMaskText",
        "type": "string"
    }, {
        "name": "directionArrow",
        "type": "string"
    }, {
        "name": "parentFieldsForChildGridTitle",
        "type": "array"
    }, {
        "name": "monitorUIUpdate",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "selectionChangeBuffer",
        "type": "number"
    }],
    "toolbox": {
        "name": "ParentChildGridPairing (Stewarts-5)",
        "category": "Grid",
        "groups": ["Grid"]
    }
}