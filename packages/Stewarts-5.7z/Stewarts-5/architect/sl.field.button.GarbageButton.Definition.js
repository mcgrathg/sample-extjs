{
    "className": "sl.field.button.GarbageButton",
    "classAlias": "widget.garbagebutton",
    "autoName": "MyGarbageButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "GarbageButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}