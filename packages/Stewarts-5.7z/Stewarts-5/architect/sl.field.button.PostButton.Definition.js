{
    "className": "sl.field.button.PostButton",
    "classAlias": "widget.postbutton",
    "autoName": "MyPostButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "PostButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}