{
    "className": "sl.field.button.ClearButton",
    "classAlias": "widget.clearbutton",
    "autoName": "MyClearButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "ClearButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}