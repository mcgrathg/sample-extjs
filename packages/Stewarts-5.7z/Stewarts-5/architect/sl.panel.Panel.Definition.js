{
    "className": "sl.panel.Panel",
    "classAlias": "widget.slpanel",
    "autoName": "MyPanel",
    "inherits": "Ext.panel.Panel",
	"configs": [{
        "name": "useStatusBar",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "statusBarPosition",
        "type": "string",
        "initialValue": "bottom"
    }, {
        "name": "includeValidationStatus",
        "type": "boolean"
    }],
    "toolbox": {
        "name": "Panel (Stewarts-5)",
        "category": "Panel",
        "groups": ["Panel"]
    }
}