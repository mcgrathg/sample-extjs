{
    "className": "sl.panel.tree.plugin.TreeStateful",
    "classAlias": "plugin.treestateful",
    "autoName": "MyTreeStateful",
    "inherits": "Ext.AbstractPlugin",
	"configs": [],
    "toolbox": {
        "name": "TreeStateful (Stewarts-5)",
        "category": "Plugin",
        "groups": ["Plugin"]
    }
}