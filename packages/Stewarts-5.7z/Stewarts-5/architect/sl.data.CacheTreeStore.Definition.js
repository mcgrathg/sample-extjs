{
    "className": "sl.data.CacheTreeStore",
    "classAlias": "store.cachetreestore",
    "autoName": "MyCacheTreeStore",
    "inherits": "Ext.data.TreeStore",
	"configs": [{
        "name": "CacheClassName",
        "type": "string"
    }, {
        "name": "CacheQueryName",
        "type": "string"
    }, {
        "name": "CacheMethodName",
        "type": "string"
    }, {
        "name": "idField",
        "type": "string",
        "initialValue": "NodeId"
    }, {
        "name": "textField",
        "type": "string",
        "initialValue": "Text"
    }, {
        "name": "leafField",
        "type": "string",
        "initialValue": "isLeaf"
    }, {
        "name": "walkTree",
        "type": "boolean",
        "initialValue": false
    }, {
        "name": "addLeafCheckbox",
        "type": "boolean",
        "initialValue": false
    }, {
        "name": "nodeParam",
        "type": "string",
        "initialValue": "nodeId"
    }],
    "toolbox": {
        "name": "CacheTreeStore (Stewarts-5)",
        "category": "Data",
        "groups": ["Data"]
    }
}