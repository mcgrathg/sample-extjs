{
    "className": "sl.field.button.ExcelButton",
    "classAlias": "widget.excelbutton",
    "autoName": "MyExcelButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "ExcelButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}