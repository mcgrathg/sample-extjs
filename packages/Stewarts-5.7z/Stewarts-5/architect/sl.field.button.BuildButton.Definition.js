{
    "className": "sl.field.button.BuildButton",
    "classAlias": "widget.buildbutton",
    "autoName": "MyBuildButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "BuildButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}