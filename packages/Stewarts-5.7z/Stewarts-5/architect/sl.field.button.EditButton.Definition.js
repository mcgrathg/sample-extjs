{
    "className": "sl.field.button.EditButton",
    "classAlias": "widget.editbutton",
    "autoName": "MyEditButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "EditButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}