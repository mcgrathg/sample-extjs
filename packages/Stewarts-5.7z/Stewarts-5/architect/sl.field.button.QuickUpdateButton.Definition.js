{
    "className": "sl.field.button.QuickUpdateButton",
    "classAlias": "widget.quickUpdateButton",
    "autoName": "MyQuickUpdateButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "QuickUpdateButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}