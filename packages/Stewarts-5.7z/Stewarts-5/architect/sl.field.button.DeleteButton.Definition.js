{
    "className": "sl.field.button.DeleteButton",
    "classAlias": "widget.deletebutton",
    "autoName": "MyDeleteButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "DeleteButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}