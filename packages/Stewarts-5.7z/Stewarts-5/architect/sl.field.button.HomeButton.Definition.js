{
    "className": "sl.field.button.HomeButton",
    "classAlias": "widget.homebutton",
    "autoName": "MyHomeButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "HomeButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}