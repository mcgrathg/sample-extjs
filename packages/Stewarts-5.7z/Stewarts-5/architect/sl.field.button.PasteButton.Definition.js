{
    "className": "sl.field.button.PasteButton",
    "classAlias": "widget.pastebutton",
    "autoName": "MyPasteButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "PasteButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}