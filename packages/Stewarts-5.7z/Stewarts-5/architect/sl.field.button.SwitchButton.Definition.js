{
    "className": "sl.field.button.SwitchButton",
    "classAlias": "widget.switchbutton",
    "autoName": "MySwitchButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "SwitchButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}