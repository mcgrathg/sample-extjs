{
    "className": "sl.field.button.PrintButton",
    "classAlias": "widget.printbutton",
    "autoName": "MyPrintButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "PrintButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}