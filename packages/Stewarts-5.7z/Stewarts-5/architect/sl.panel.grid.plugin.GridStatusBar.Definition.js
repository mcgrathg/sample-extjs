{
    "className": "sl.panel.grid.plugin.GridStatusBar",
    "classAlias": "widget.slgridstatusbar",
    "autoName": "MyGridStatusBar",
    "inherits": "sl.panel.StatusBar",
	"configs": [],
    "toolbox": {
        "name": "GridStatusBar (Stewarts-5)",
        "category": "Plugin",
        "groups": ["Plugin"]
    }
}