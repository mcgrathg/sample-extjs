{
    "className": "sl.field.button.NewButton",
    "classAlias": "widget.newbutton",
    "autoName": "MyNewButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "NewButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}