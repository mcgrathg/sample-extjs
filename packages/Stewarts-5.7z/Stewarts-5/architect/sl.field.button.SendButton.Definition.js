{
    "className": "sl.field.button.SendButton",
    "classAlias": "widget.sendbutton",
    "autoName": "MySendButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "SendButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}