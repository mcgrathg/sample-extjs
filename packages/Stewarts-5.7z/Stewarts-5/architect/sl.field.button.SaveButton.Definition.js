{
    "className": "sl.field.button.SaveButton",
    "classAlias": "widget.savebutton",
    "autoName": "MySaveButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "SaveButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}