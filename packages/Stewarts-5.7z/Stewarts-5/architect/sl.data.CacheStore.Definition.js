{
    "className": "sl.data.CacheStore",
    "classAlias": "store.cachestore",
    "autoName": "MyCacheStore",
    "inherits": "Ext.data.Store",
	"configs": [{
        "name": "saveIndividually",
        "type": "boolean",
        "initialValue": false
    }, {
        "name": "isStoreValidatedOnLoad",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "isRecordChangeValidated",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "isNewRecordValidated",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "CacheClassName",
        "type": "string",
        "initialValue": "**Required**"
    }, {
        "name": "CacheQueryName",
        "type": "string",
        "initialValue": "**Required**"
    }, {
        "name": "CacheMethodName",
        "type": "string"
    }, {
        "name": "extraParams",
        "type": "object"
    }, {
        "name": "saveConfig",
        "type": "object"
    }, {
        "name": "deleteConfig",
        "type": "object"
    }],
    "toolbox": {
        "name": "CacheStore (Stewarts-5)",
        "category": "Data",
        "groups": ["Data"]
    }
}