{
    "className": "sl.field.ListCombo",
    "classAlias": "widget.listcombo",
    "autoName": "MyListCombo",
    "inherits": "sl.field.ComboBox",
	"configs": [{
        "name": "CacheClassName",
        "type": "string",
        "initialValue": "**Required**"
    }, {
        "name": "CachePropertyName",
        "type": "string",
        "initialValue": "**Required**"
    }, {
        "name": "displayField",
        "type": "string",
        "initialValue": "Display"
    }, {
        "name": "valueField",
        "type": "string",
        "initialValue": "Value"
    }, {
        "name": "initExpr",
        "type": "string"
    }, {
        "name": "useInitialExpression",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "useExternalValue",
        "type": "boolean",
        "initialValue": true
    }],
    "toolbox": {
        "name": "ListCombo (Stewarts-5)",
        "category": "Field",
        "groups": ["Field"]
    }
}