{
    "className": "sl.panel.ReportPanel",
    "classAlias": "widget.reportpanel",
    "autoName": "MyReportPanel",
    "inherits": "Ext.panel.Panel",
	"configs": [{
        "name": "url",
        "type": "string"
    }, {
        "name": "displayMode",
        "type": "string",
        "initialValue": "pdf"
    }, {
        "name": "reportParams",
        "type": "object"
    }],
    "toolbox": {
        "name": "ReportPanel (Stewarts-5)",
        "category": "Panel",
        "groups": ["Panel"]
    }
}