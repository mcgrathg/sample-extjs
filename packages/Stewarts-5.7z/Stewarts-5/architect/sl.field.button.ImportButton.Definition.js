{
    "className": "sl.field.button.ImportButton",
    "classAlias": "widget.importbutton",
    "autoName": "MyImportButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "ImportButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}