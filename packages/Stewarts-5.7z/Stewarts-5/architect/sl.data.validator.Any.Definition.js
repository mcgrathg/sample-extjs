{
    "className": "sl.data.validator.Any",
    "classAlias": "data.validator.any",
    "autoName": "MyAny",
    "inherits": "Ext.data.validator.Validator",
	"configs": [{
        "name": "message",
        "type": "string"
    }, {
        "name": "allowFalse",
        "type": "boolean"
    }, {
        "name": "messageNames",
        "type": "string"
    }],
    "toolbox": {
        "name": "Any (Stewarts-5)",
        "category": "Validator",
        "groups": ["Validator"]
    }
}