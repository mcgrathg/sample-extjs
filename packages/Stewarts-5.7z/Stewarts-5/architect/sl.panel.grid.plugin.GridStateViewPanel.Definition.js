{
    "className": "sl.panel.grid.plugin.GridStateViewPanel",
    "classAlias": "plugin.gridstateviewpanel",
    "autoName": "MyGridStateViewPanel",
    "inherits": "Ext.util.Observable",
	"configs": [{
        "name": "providerType",
        "type": "string",
        "initialValue": "local"
    }, {
        "name": "displayAsButton",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "buttonText",
        "type": "string",
        "initialValue": "Saved Views"
    }, {
        "name": "includeViewPanel",
        "type": "boolean",
        "initialValue": true
    }, {
        "name": "toolbarId",
        "type": "string"
    }, {
        "name": "toolbarPosition",
        "type": "string",
        "initialValue": "bottom"
    }, {
        "name": "align",
        "type": "string",
        "initialValue": "right"
    }],
    "toolbox": {
        "name": "GridStateViewPanel (Stewarts-5)",
        "category": "Plugin",
        "groups": ["Plugin"]
    }
}