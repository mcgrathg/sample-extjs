{
    "className": "sl.field.button.ConfirmButton",
    "classAlias": "widget.confirmbutton",
    "autoName": "MyConfirmButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "ConfirmButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}