{
    "className": "sl.field.button.FindButton",
    "classAlias": "widget.findbutton",
    "autoName": "MyFindButton",
    "inherits": "Ext.button.Button",
	"configs": [],
    "toolbox": {
        "name": "FindButton (Stewarts-5)",
        "category": "Button",
        "groups": ["Button"]
    }
}